var eventTarget = "";
var LivestockLocationNbrs = "";
var LivestockPlaces = "";
var LivestockListLength = "";
var LivestockList = "";
var DrugNbrs = "";
var Drugs = "";
var DiagnosisNbrs = "";
var Diagnosis = "";
var AnimalSpeciesLength = "";
var AnimalSpeciesList = "";
var LivestockGroupListLength = "";
var LivestockGroupList = "";
var AnimalColorNbr = "";
var AnimalColor = "";
var AnimalColorNbr = "";
var UnitsLength = "";
var UnitsList = "";

var BaseUrl = 'http://3.126.208.157:81'

// var SwaggerPetstore = require('swagger_petstore');

// var api = new SwaggerPetstore.AnotherFakeApi()

// var body = new SwaggerPetstore.Client(); // {Client} client model


// var callback = function(error, data, response) {
//   if (error) {
//     console.error(error);
//   } else {
//     console.log('API called successfully. Returned data: ' + data);
//   }
// };
// api.testSpecialTags(body, callback);


// import AuthenticationApi from '../api/index'; // See note below*.







//User  Login
function RESTLogin() {
    const loginParameter = new LoginParameter();
//     // console.log(newLogin.drive());
    loginParameter.UserName = document.getElementById("email").value;
    loginParameter.Password = document.getElementById("psw").value;

//     var endpoint = BaseUrl + '/api/Authentication/Login';
//     var data = JSON.stringify(loginParameter);
// var obj = JSON.parse(data);
// console.log(data)
// $.ajax({
// url: 'http://3.126.208.157:81/api/Authentication/Login',
// contentType: "application/json",
// type: "POST",
// data: JSON.stringify({"userName":"markus.breiteneder@gmail.com","password":"ua3z6P9o9lLZEh2fAVTY"}),
//         success: function (response) {
//             var data = JSON.stringify(response);
//             var obj = JSON.parse(data);
//             alert(obj)
//             },
//         error: function (xhr, status, error) {
//             var errorMessage = xhr.status + ': ' + xhr.statusText
//             alert('Login failed! Error - ' + errorMessage);
//         }
// });

   
    const newAuth = new AuthenticationClient();

    newAuth.Login(loginParameter, function(response) {
        var token = "bearer " + response.token
        alert(token)
        alert(response.success);
      }, function(xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Login failed! Error - ' + errorMessage);
      }); 

    // alert(newAuth.Login.successCallback)

    //   newAuth.Login({
    //     success: function (successCallback) {
    //         var data = JSON.stringify(successCallback);
    //         var obj = JSON.parse(data);
    //         alert(obj)
    //         }
    //   });
    // var specUrl = 'http://petstore.swagger.io/v2/swagger.json'; // data urls are OK too 'data:application/json;base64,abc...'
    // SwaggerClient.http.withCredentials = true; // this activates CORS, if necessary
    
    // var swaggerClient = new SwaggerClient(specUrl)
    //       .then(function (swaggerClient) {
    //           return swaggerClient.apis.pet.addPet({id: 1, name: "bobby"}); // chaining promises
    //       }, function (reason) {
    //          console.error("failed to load the spec" + reason);
    //       })
    //       .then(function(addPetResult) {
    //          console.log(addPetResult.obj);
    //          // you may return more promises, if necessary
    //       }, function (reason) {
    //           console.error("failed on API call " + reason);
    //       });


    // $.getJSON('../json/swagger.json', function(schema){
    //     var api = swaggerAjaxClient(schema);
  
    //     function getOrCreate(id, name){
    //       return api.pet.getPetById(id).catch(function(response){
    //         // If pet doesn't exist, create a new one.
    //         if(response.status === 404){
    //           var pet = {id: id, name: name};
    //           return api.pet.addPet(pet).then(function(){
    //             return pet;
    //           });
    //         }
  
    //         // Unknown error
    //         console.error(response.error.toString());
    //       });
    //     }
  
    //     getOrCreate(23, 'bob').then(function(pet){
    //       console.log('Got pet:', pet);
    //     }, function(error){
    //       console.error(error.toString());
    //     });
    //   });


//     $.getJSON('../json/swagger.json', function(schema){
//         var api = swaggerAjaxClient(schema);
    

            
//         var loginParamter = {username: usernameInput, password: passwordInput};
//         api.Authentication.Login(loginParamter);
// });

    //     function getOrCreate(id, name){
    //       return api.pet.getPetById(id).catch(function(response){
    //         // If pet doesn't exist, create a new one.
    //         if(response.status === 404){
    //           var pet = {id: id, name: name};
    //           return api.pet.addPet(pet).then(function(){
    //             return pet;
    //           });
    //         }
    
    //         // Unknown error
    //         console.error(response.error.toString());
    //       });
    //     }
    
    //     getOrCreate(23, 'bob').then(function(pet){
    //       console.log('Got pet:', pet);
    //     }, function(error){
    //       console.error(error.toString());
    //     });
    //   });


    // var Api = await import('../api/index');
    // var Authentication = new Api.AuthenticationApi(); // Allocate the API class we're going to use.
    // var LoginParameter = new Api._LoginParameter(); // Construct a model instance.
    // LoginParameter.userName = document.getElementById("email").value;
    // LoginParameter.password = document.getElementById("psw").value;
    
    // var callback = function(error, data, response) {
    //     console.log(response)
    //     if (error) {
    //       console.error(error);
    //     } else {
    //       console.log('API called successfully. Returned data: ' + data);
    //     }
    //   };

    // var zzz = Authentication.apiAuthenticationLoginPost(LoginParameter, callback);


    // // // document.querySelector('#nav1').pushPage('home_splitter.html');
    // var endpoint = 'http://3.126.208.157:81/api/Authentication/Login'
    
    // alert(endpoint)
    // $.ajax({
    //     // headers: {
    //     //     'Cache-Control': 'no-cache',
    //     //     'Content-Type': 'application/json',
    //     //     'Accept': '*/*'
    //     // },
    //     crossDomain: true,
    //     url: endpoint, 
    //     // crossDomain: true,
    //     // contentType: "application/x-www-form-urlencoded",
    //     // contentType: "application/json",
    //     contentType: "application/json; charset=utf-8",

    //     type: "POST",
    //     data: JSON.stringify({
    //         "userName": "markus.breiteneder@gmail.com",
    //         "password": "ua3z6P9o9lLZEh2fAVTY"
    //     }),
    //     success: function (response) {
    //         alert('funkt')  
    //         alert(response) 
    //         // var token = "bearer " + response.token
    //         // var data = JSON.stringify(response);
    //         // var obj = JSON.parse(data);

    //         // localStorage.setItem("firstname", response.user.firstName);
    //         // localStorage.setItem("lastname", response.user.lastName);
    //         // localStorage.setItem("password", response.user.password);
    //         // localStorage.setItem("lfbis", response.customer.lfbisId);
    //         // localStorage.setItem("user_email", email);
    //         // localStorage.setItem("bearerToken", token);

    //         // // check if login is successfull
    //         // if (response.success == true) {
    //         //     //get Livestock Database from server
    //         //     RESTGetLivestock()
    //         //     //get Livestock location
    //         //     RESTGetLocation()
    //         //     //get Drugs 
    //         //     RESTGetDrugs()
    //         //     //get Diagnosis 
    //         //     RESTGetDiagnosis()
    //         //     //get Animal Species 
    //         //     RESTGetAnimalSpecies()
    //         //     //get Animal Groups
    //         //     RESTGetAnimalGroup()
    //         //     //get Animal Color
    //         //     RESTGetAnimalColor()
    //         //     //get Units
    //         //     RESTGetUnits()
    //         //     document.querySelector('#nav1').pushPage('home_splitter.html');
    //         // } else {
    //         //     pushMsg(obj.messages[0].message)
    //         // }
    //     },
    //     error: function (xhr, status, error) {
    //         var errorMessage = xhr.status + ': ' + xhr.statusText
    //         alert('Login failed! Error - ' + errorMessage);
    //     }
    // });
}

//REST get all Livestocks
function RESTGetLivestock() {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/animal/getanimals'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        crossDomain: true,
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({}),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //get numbers of entries
            LivestockListLength = data.split("id").length - 1;
            //save livestocks in global variable
            LivestockList = obj.list;
            if (eventEnterPageId === 'Bestandsliste Arzneimittel') {
                document.querySelector('#nav1').popPage();
                updateLivestockView()
            }
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Livestock get failed! Error - ' + errorMessage);
        }
    });
}

//REST add Livestock 
function RESTAddLivestock(birthday, color, number, AnimalLocationId) {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/Animal/SaveAnimal'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({
            "model": {
                "animalLocationId": AnimalLocationId,
                "typeId": 2,
                "number": number,
                "color": color,
                "birthday": birthday
            }
        }),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //check if livestock add is OK
            if (response.success === true) {
                RESTGetLivestock()
                document.querySelector('#nav1').popPage();
            } else {
                //check if current page is livestock_add page
                // if (eventEnterPageId === 'livestock_add') {
                //     ons.notification.alert({
                //         message: 'Nutztier ist bereits in der Datenbank hinterlegt',
                //         title: 'Nutztier vorhanden',
                //     });
                // }

                pushMsg(obj.messages[0].message)
            }
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Livestock add failed! Error - ' + errorMessage);
        }
    });
}

//REST add Livestock 
function RESTUpdateLivestock(ID, born, color, number, AnimalLocationId) {
    alert('hallo')
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/Animal/SaveAnimal'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({
            "model": {
                "id":ID,
                "animalLocationId": AnimalLocationId,
                "typeId": 2,
                "number": number,
                "color": color,
                "birthday": born
            }
        }),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //check if livestock add is OK
            if (response.success === true) {
                RESTGetLivestock()
                document.querySelector('#nav1').popPage();
            } else {
                //check if current page is livestock_add page
                // if (eventEnterPageId === 'livestock_add') {
                //     ons.notification.alert({
                //         message: 'Nutztier ist bereits in der Datenbank hinterlegt',
                //         title: 'Nutztier vorhanden',
                //     });
                // }

                pushMsg(obj.messages[0].message)
            }
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Livestock add failed! Error - ' + errorMessage);
        }
    });
}


//REST add group of livestocks 
function RESTAddLivestockGroup() {
    var place = document.getElementById("animalGroupPlaceText").innerHTML;
    var number = document.getElementById("animalGroupNumberText").value;
    var count = document.getElementById("animalGroupCountText").value;
    var category = document.getElementById("animalGroupCategoryText").innerHTML;
    var born = document.getElementById("animalGroupBornOnText").value;
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/animal/creategroupofanimals'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({
            "model": {
                "count": count,
                "animalLocationBoxNumber": number,
                "animalLocationId": place,
                "animalSpeciesId": category,
                "birthday": born,
                "GroupName": number,
            }
        }),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //check if livestock add is OK
            if (response.success === true) {
                document.querySelector('#nav1').popPage();
            } else {
                pushMsg(obj.messages[0].message)
            }
        },

        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Livestock add failed! Error - ' + errorMessage);
        }
    });
}

//REST get group of livestocks
function RESTGetAnimalGroup() {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/animalgroup/getanimalgroups'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        crossDomain: true,
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({}),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //get numbers of entries
            LivestockGroupListLength = data.split("id").length - 1;
            //save livestocks in global variable
            LivestockGroupList = obj.list;
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Livestock Group get failed! Error - ' + errorMessage);
        }
    });
}

//REST get group of livestocks
function RESTGetUnits() {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/unit/getunits'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        crossDomain: true,
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({}),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //get numbers of entries
            UnitsLength = data.split("id").length - 1;
            //save livestocks in global variable
            UnitsList = obj.list;
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Livestock Units get failed! Error - ' + errorMessage);
        }
    });
}


//REST delete Livestock 
function RESTDeleteAnimal(id) {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/Animal/DeleteAnimal'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({
            "id": id
        }),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //check if livestock delete is OK
            if (response.success === true) {
                RESTGetLivestock();
            } else {
                pushMsg(obj.messages[0].message)
            }
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Livestock delete failed! Error - ' + errorMessage);
        }
    });
}

//REST get all Livestocks
function RESTGetAnimalSpecies() {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/animalspecies/getanimalspecies'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        crossDomain: true,
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({}),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //get numbers of entries
            AnimalSpeciesLength = data.split("id").length - 1;
            //save Animal Species in global variable
            AnimalSpeciesList = obj.list;
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Livestock get species failed! Error - ' + errorMessage);
        }
    });
}

function RESTGetLocation() {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/Animallocation/Getanimallocations'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({}),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //get numbers of entries
            LivestockLocationNbrs = data.split("id").length - 1;
            //save places in global variable
            LivestockPlaces = obj.list;

            if (eventEnterPageId === 'livestock_add') {
                updateLivestockLocations()
            }
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Get Location failed! Error - ' + errorMessage);
        }
    });
}

function RESTSaveLocation(location) {
    var token = localStorage.getItem("bearerToken")
    var user_email = localStorage.getItem("user_email")
    var endpoint = EndpointLink + '/api/Animallocation/Saveanimallocation'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({
            "model": {
                "CreatedBy": user_email,
                "name": location
            }
        }),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            // check if new Location was successfully saved
            if (response.success == true) {
                RESTGetLocation()
            } else {
                pushMsg(obj.messages[0].message)
            }
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Save Location failed! Error - ' + errorMessage);
        }
    });
}

function RESTDeleteLocation(id) {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/Animallocation/Deleteanimallocation'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({
            "id": id
        }),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            // check if new Location was successfully deleted
            if (response.success == true) {
                RESTGetLocation()
            } else {
                pushMsg(obj.messages[0].message)
            }
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Get Location failed! Error - ' + errorMessage);
        }
    });
}

function RESTGetAnimalColor() {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/animalcolor/getanimalcolors'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({}),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //get numbers of entries
            AnimalColorNbr = data.split("id").length - 1;
            //save places in global variable
            AnimalColor = obj.list;
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Get Animal Color failed! Error - ' + errorMessage);
        }
    });
}

function RESTGetDrugs() {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/Drug/GetDrugs'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({}),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //get numbers of entries
            DrugNbrs = data.split("id").length - 1;
            //save drugs in global variable
            Drugs = obj.list;
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Get Drugs failed! Error - ' + errorMessage);
        }
    });
}

function RESTGetDiagnosis() {
    var token = localStorage.getItem("bearerToken")
    var endpoint = EndpointLink + '/api/Diagnosis/GetDiagnoses'
    $.ajax({
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': token
        },
        url: endpoint,
        contentType: "application/json",
        type: "POST",
        data: JSON.stringify({}),
        success: function (response) {
            var data = JSON.stringify(response);
            var obj = JSON.parse(data);
            //get numbers of entries
            DiagnosisNbrs = data.split("id").length - 1;
            //save drugs in global variable
            Diagnosis = obj.list;
        },
        error: function (xhr, status, error) {
            var errorMessage = xhr.status + ': ' + xhr.statusText
            alert('Get Drugs failed! Error - ' + errorMessage);
        }
    });
}

pushMsg = function (msg) {
    ons.notification.toast(msg, {
        timeout: 3000,
        animation: 'fall'
    })
}